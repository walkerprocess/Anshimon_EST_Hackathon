# -*- coding: utf-8 -*-
"""엔드투엔드 진입점 - Spring이 호출할 함수

문서 수집·청킹(ingest) -> 검색(retrieval) -> 프롬프트(prompt_builder) ->
생성(llm_client) -> 근거 검증(evidence_verifier) -> 출력 스키마(schemas) 를
하나의 흐름으로 연결한다.

근거 검증에서 ERROR가 하나라도 나오면 GuidanceGenerationError를 던져
자동전화 발신을 보류시킨다 (기획안 완료기준: "누락된 핵심 데이터가 있으면
자동전화가 보류된다" 원칙을 근거 오류 상황까지 확장 적용).
"""
from __future__ import annotations

from functools import lru_cache
from typing import Any, Optional

import evidence_verifier
import prompt_builder
import llm_client
from retrieval import search as retrieve_chunks
from schemas import AlternativeShelter, GuidanceSentence, InterventionPlan, RiskLevel, ShelterRecommendation
from shelter_reference import ShelterReferenceIndex, load_default_index


class GuidanceGenerationError(Exception):
    """근거 검증 ERROR로 인해 안내 계획 생성을 보류할 때 발생시킨다.

    Spring 쪽 guidance/contact 모듈은 이 예외를 받으면 자동전화 발신을 하지 않고
    issues를 로그/알림으로 노출해야 한다.
    """

    def __init__(self, elderly_id: int, risk_snapshot_id: int, issues: list[evidence_verifier.VerificationIssue]):
        self.elderly_id = elderly_id
        self.risk_snapshot_id = risk_snapshot_id
        self.issues = issues
        summary = "; ".join(str(i) for i in issues if i.level == "ERROR")
        super().__init__(
            f"elderly_id={elderly_id} risk_snapshot_id={risk_snapshot_id} 근거 검증 실패로 "
            f"자동전화 발신을 보류합니다: {summary}"
        )


@lru_cache(maxsize=1)
def _shelter_index() -> ShelterReferenceIndex:
    return load_default_index()


def _build_search_query(elderly_profile: dict, risk_snapshot: dict) -> str:
    audience = elderly_profile.get("targetAudience") or elderly_profile.get("target_audience") or []
    risk_level = risk_snapshot.get("riskLevel") or risk_snapshot.get("risk_level") or ""
    risk_factors = risk_snapshot.get("riskFactors") or risk_snapshot.get("risk_factors") or []
    parts = [" ".join(audience), f"위험도 {risk_level}", " ".join(risk_factors), "폭염 온열질환 예방 수칙"]
    return " ".join(p for p in parts if p).strip()


def generate_intervention_plan(
    elderly_id: int,
    risk_snapshot_id: int,
    elderly_profile: dict,
    risk_snapshot: dict,
    shelter: Optional[dict] = None,
    weather: Optional[dict] = None,
) -> dict:
    """Spring이 호출하는 엔드투엔드 진입점.

    성공 시 기획안 6.2 "최종 안내 계획" 스키마와 동일한 dict를 반환한다.
    근거 검증 ERROR가 있으면 GuidanceGenerationError를 던진다 (자동전화 보류).
    """
    weather = weather or {}
    audience = elderly_profile.get("targetAudience") or elderly_profile.get("target_audience") or []

    risk_level_raw = risk_snapshot.get("riskLevel") or risk_snapshot.get("risk_level")
    if risk_level_raw == "CRITICAL" and "EMERGENCY" not in audience:
        audience = [*audience, "EMERGENCY"]

    query = _build_search_query(elderly_profile, risk_snapshot)
    evidence_chunks = retrieve_chunks(query, target_audience=audience, top_k=5)
    retrieved_chunk_ids = {c.chunk_id for c in evidence_chunks}

    messages_payload = prompt_builder.build_messages(
        elderly_profile, risk_snapshot, shelter, weather, evidence_chunks
    )
    raw_output = llm_client.generate_guidance(
        evidence_chunks, risk_snapshot, shelter, messages_payload=messages_payload
    )

    structured_context: dict[str, Any] = {
        "profile": elderly_profile,
        "risk": risk_snapshot,
        "weather": weather,
        "shelter": shelter,
    }
    issues = evidence_verifier.verify_guidance_output(
        raw_output, retrieved_chunk_ids, structured_context, shelter_ref=_shelter_index()
    )

    if evidence_verifier.has_errors(issues):
        raise GuidanceGenerationError(elderly_id, risk_snapshot_id, issues)

    recommended_shelter = None
    if raw_output.get("recommendedShelter"):
        s = raw_output["recommendedShelter"]
        recommended_shelter = ShelterRecommendation(
            name=s.get("name", ""),
            address=s.get("address", ""),
            distance_m=s.get("distanceM"),
            source="pipeline",
            lat=s.get("lat"),
            lon=s.get("lon"),
            walk_minutes=s.get("walkMinutes"),
            walk_meters=s.get("walkMeters"),
            crossings=s.get("crossings"),
            open_status=s.get("openStatus"),
            needs_review=s.get("needsReview", False),
            route=s.get("route", []),
            alternatives=[AlternativeShelter.model_validate(a) for a in s.get("alternatives", [])],
        )

    plan = InterventionPlan(
        elderly_id=elderly_id,
        risk_snapshot_id=risk_snapshot_id,
        risk_level=RiskLevel(risk_level_raw),
        guidance_sentences=[
            GuidanceSentence(text=s["text"], evidence_chunk_ids=s.get("evidenceChunkIds", []))
            for s in raw_output.get("guidanceSentences", [])
        ],
        recommended_shelter=recommended_shelter,
        emergency_flag=raw_output.get("emergencyFlag", False),
        emergency_message=raw_output.get("emergencyMessage"),
        model_used=raw_output.get("_modelUsed", "unknown"),
    )
    return plan.to_contract_json()


if __name__ == "__main__":
    import json

    demo_profile = {
        "targetAudience": ["ELDERLY"],
        "age": 82,
        "livesAlone": True,
    }
    demo_weather = {"temperatureC": 36.2, "heatWarning": "폭염경보"}

    print("=== 케이스 1: 정상 흐름 (실존 쉼터) ===")
    good_shelter = {"name": "종로노인종합복지관 경로당", "address": "서울특별시 종로구 삼봉로 71"}
    plan_json = generate_intervention_plan(
        elderly_id=101,
        risk_snapshot_id=812,
        elderly_profile=demo_profile,
        risk_snapshot={"riskLevel": "HIGH", "riskScore": 0.83, "riskFactors": ["독거", "고령"]},
        shelter=good_shelter,
        weather=demo_weather,
    )
    print(json.dumps(plan_json, ensure_ascii=False, indent=2))

    print("\n=== 케이스 2: 쉼터 실존 검증 실패 -> 자동전화 보류 ===")
    fake_shelter = {"name": "가상의쉼터12345 (실존하지않음)", "address": "서울특별시 어딘가 999"}
    try:
        generate_intervention_plan(
            elderly_id=102,
            risk_snapshot_id=813,
            elderly_profile=demo_profile,
            risk_snapshot={"riskLevel": "HIGH", "riskScore": 0.7, "riskFactors": ["고령"]},
            shelter=fake_shelter,
            weather=demo_weather,
        )
    except GuidanceGenerationError as e:
        print(f"자동전화 보류됨: {e}")
        for issue in e.issues:
            print(" ", issue)

    print("\n=== 케이스 3: TMAP 경로 포함 (t-map_location_connection_ansimon/recommend.py 출력 형태) ===")
    tmap_shelter = {
        "name": "종로노인종합복지관 경로당",
        "address": "서울특별시 종로구 삼봉로 71",
        "lat": 37.5729,
        "lon": 126.9794,
        "walk_minutes": 3,
        "walk_meters": 162,
        "crossings": 1,
        "open_status": "UNKNOWN",
        "needs_review": False,
        "route": ["80m 이동", "횡단보도 건너기", "도착"],
        "alternatives": [{"name": "다른쉼터", "walk_minutes": 4, "crossings": 0}],
    }
    plan_json = generate_intervention_plan(
        elderly_id=103,
        risk_snapshot_id=814,
        elderly_profile=demo_profile,
        risk_snapshot={"riskLevel": "HIGH", "riskScore": 0.75, "riskFactors": ["고령"]},
        shelter=tmap_shelter,
        weather=demo_weather,
    )
    print(json.dumps(plan_json["recommendedShelter"], ensure_ascii=False, indent=2))

    print("\n=== 케이스 4: TMAP 경로 needs_review=true -> 자동전화 보류 ===")
    unreviewed_shelter = {**tmap_shelter, "needs_review": True, "walk_minutes": 24}
    try:
        generate_intervention_plan(
            elderly_id=104,
            risk_snapshot_id=815,
            elderly_profile=demo_profile,
            risk_snapshot={"riskLevel": "HIGH", "riskScore": 0.75, "riskFactors": ["고령"]},
            shelter=unreviewed_shelter,
            weather=demo_weather,
        )
    except GuidanceGenerationError as e:
        print(f"자동전화 보류됨: {e}")
        for issue in e.issues:
            print(" ", issue)
