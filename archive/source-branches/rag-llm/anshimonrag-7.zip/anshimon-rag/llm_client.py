# -*- coding: utf-8 -*-
"""생성 단계: 실제 Alan API 호출 + 오프라인 mock 폴백

ALAN_API_KEY 환경변수가 있으면 실제 Alan LLM을 호출하고,
없으면 검색된 근거 청크에서 문장을 그대로 채택하는 결정론적 mock 생성기로
자동 폴백한다. 두 경로 모두 prompt_builder.OUTPUT_JSON_SHAPE와 동일한 형태의
dict를 반환하므로, 호출부(pipeline.py)는 어느 경로를 탔는지 신경 쓸 필요가 없다.

주의: 이 저장소를 만든 시점에는 Alan API의 정확한 엔드포인트/요청·응답 필드명을
확인할 수 없었다 (해커톤 주최측인 ESTsoft가 참가팀에만 비공개로 배포한 문서로
추정됨). 아래 _call_alan_api()는 일반적인 REST LLM API 관례(Bearer 인증,
JSON in/out)를 따른 최선의 추정 구현이다. 실제 문서를 받으면 ALAN_API_URL과
요청/응답 필드명(각각 "요청 body 구성"/"응답 파싱" 주석 표시 부분)을 맞춰
수정해야 한다.
"""
from __future__ import annotations

import json
import os
import re
from dataclasses import asdict, is_dataclass
from typing import Any, Optional

import requests

from schemas import EMERGENCY_GUIDANCE_TEMPLATE

DEFAULT_MODEL = "alan"
DEFAULT_MAX_TOKENS = 1500
MOCK_MODEL_NAME = "mock-deterministic-v1"
ALAN_REQUEST_TIMEOUT_SECONDS = 30

_CODE_FENCE_RE = re.compile(r"^```(?:json)?\s*|\s*```$", re.MULTILINE)


def _to_plain(chunk: Any) -> dict:
    if is_dataclass(chunk) and not isinstance(chunk, type):
        return asdict(chunk)
    return chunk


def _call_real_api(messages_payload: dict, api_key: str) -> dict:
    """Alan API를 호출해 안내 계획 초안 JSON을 받아온다.

    TODO(Alan API 문서 확인 필요): 아래 항목들은 실제 문서를 받으면 교체해야 한다.
      1. ALAN_API_URL — 지금은 환경변수로 필수 지정하게 해뒀다 (기본 엔드포인트 모름)
      2. 인증 헤더 이름/형식 — 지금은 `Authorization: Bearer <key>`로 가정
      3. 요청 body 필드명 — 지금은 {"system": ..., "messages": [...]} 형태로 보냄
         (prompt_builder.build_messages()가 만드는 system/messages를 그대로 전달)
      4. 응답 파싱 — 지금은 response JSON에서 "content"/"answer"/"result" 순으로
         텍스트 필드를 찾는다. 실제 필드명이 다르면 이 부분만 고치면 된다.
    """
    endpoint = os.environ.get("ALAN_API_URL")
    if not endpoint:
        raise RuntimeError(
            "ALAN_API_URL 환경변수가 설정되지 않았습니다. Alan API의 실제 엔드포인트 "
            "URL을 확인한 뒤 설정해주세요. (예: ALAN_API_URL=https://api.alan.est.ai/v1/chat)"
        )

    response = requests.post(
        endpoint,
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        },
        json={
            # 요청 body 구성 — Alan 문서 확인되면 이 형태를 맞춰 수정
            "model": messages_payload.get("model", DEFAULT_MODEL),
            "system": messages_payload["system"],
            "messages": messages_payload["messages"],
            "max_tokens": messages_payload.get("max_tokens", DEFAULT_MAX_TOKENS),
        },
        timeout=ALAN_REQUEST_TIMEOUT_SECONDS,
    )
    response.raise_for_status()
    data = response.json()

    # 응답 파싱 — Alan 문서 확인되면 실제 필드명으로 교체
    raw_text = data.get("content") or data.get("answer") or data.get("result") or ""
    if not raw_text:
        raise RuntimeError(
            f"Alan API 응답에서 텍스트를 찾지 못했습니다. 실제 응답 필드명을 확인해서 "
            f"_call_real_api()의 파싱 부분을 수정해주세요. 원본 응답: {data!r}"
        )

    cleaned = _CODE_FENCE_RE.sub("", raw_text).strip()
    return json.loads(cleaned)


def _find_emergency_template_chunk(evidence_chunks: list[Any]) -> Optional[dict]:
    for c in evidence_chunks:
        c = _to_plain(c)
        if c["text"] == EMERGENCY_GUIDANCE_TEMPLATE:
            return c

    from retrieval import load_active_chunks

    for c in load_active_chunks():
        if c["text"] == EMERGENCY_GUIDANCE_TEMPLATE:
            return c
    return None


def _mock_generate(
    evidence_chunks: list[Any],
    risk_snapshot: dict,
    shelter: Optional[dict],
    max_sentences: int = 4,
) -> dict:
    """검색된 근거 청크의 문장을 그대로 채택하는 결정론적 mock 생성기."""
    plain_chunks = [_to_plain(c) for c in evidence_chunks]

    guidance_sentences = [
        {"text": c["text"], "evidenceChunkIds": [c["chunk_id"]]}
        for c in plain_chunks[:max_sentences]
        if c["text"] != EMERGENCY_GUIDANCE_TEMPLATE
    ]

    risk_level = (risk_snapshot or {}).get("riskLevel") or (risk_snapshot or {}).get("risk_level")
    emergency_flag = risk_level == "CRITICAL"
    emergency_message = None
    if emergency_flag:
        template_chunk = _find_emergency_template_chunk(plain_chunks)
        if template_chunk:
            emergency_message = EMERGENCY_GUIDANCE_TEMPLATE
            guidance_sentences.append(
                {"text": EMERGENCY_GUIDANCE_TEMPLATE, "evidenceChunkIds": [template_chunk["chunk_id"]]}
            )

    recommended_shelter = None
    if shelter:
        # shelter 모듈(t-map_location_connection_ansimon/recommend.py)이 넘겨주는
        # TMAP 보행자 경로 필드는 그대로 통과시킨다. recommend.py 원본은 snake_case,
        # Spring 계약은 camelCase라 두 케이싱 다 지원한다.
        recommended_shelter = {
            "name": shelter.get("name"),
            "address": shelter.get("address"),
            "distanceM": shelter.get("distanceM", shelter.get("distance_m")),
            "lat": shelter.get("lat"),
            "lon": shelter.get("lon"),
            "walkMinutes": shelter.get("walkMinutes", shelter.get("walk_minutes")),
            "walkMeters": shelter.get("walkMeters", shelter.get("walk_meters")),
            "crossings": shelter.get("crossings"),
            "openStatus": shelter.get("openStatus", shelter.get("open_status")),
            "needsReview": shelter.get("needsReview", shelter.get("needs_review", False)),
            "route": shelter.get("route", []),
            "alternatives": shelter.get("alternatives", []),
        }

    return {
        "guidanceSentences": guidance_sentences,
        "emergencyFlag": emergency_flag,
        "emergencyMessage": emergency_message,
        "recommendedShelter": recommended_shelter,
        "_modelUsed": MOCK_MODEL_NAME,
    }


def generate_guidance(
    evidence_chunks: list[Any],
    risk_snapshot: dict,
    shelter: Optional[dict] = None,
    messages_payload: Optional[dict] = None,
) -> dict:
    """근거 청크 + 구조화 컨텍스트로 안내 계획 초안(JSON dict)을 생성한다.

    반환 dict에는 어떤 모델이 생성했는지 알 수 있도록 "_modelUsed" 키가
    추가로 들어간다 (pipeline.py가 InterventionPlan.model_used에 채워 넣는다).
    """
    api_key = os.environ.get("ALAN_API_KEY")
    if api_key:
        if messages_payload is None:
            raise ValueError("실제 API 호출에는 prompt_builder.build_messages() 결과가 필요합니다.")
        result = _call_real_api(messages_payload, api_key)
        result["_modelUsed"] = messages_payload.get("model", DEFAULT_MODEL)
        return result

    return _mock_generate(evidence_chunks, risk_snapshot, shelter)


if __name__ == "__main__":
    from retrieval import search

    print(f"ALAN_API_KEY 설정됨: {bool(os.environ.get('ALAN_API_KEY'))}")

    print("\n=== 일반 위험도(HIGH) mock 생성 ===")
    chunks = search("노인 폭염 대비 수칙", target_audience=["ELDERLY"], top_k=3)
    result = generate_guidance(chunks, {"riskLevel": "HIGH"}, shelter={"name": "종로노인종합복지관 경로당", "address": "서울특별시 종로구 삼봉로 71"})
    print(json.dumps(result, ensure_ascii=False, indent=2))

    print("\n=== CRITICAL 위험도(응급 문구 포함) mock 생성 ===")
    chunks = search("의식 잃음 응급조치", target_audience=["EMERGENCY", "ELDERLY"], top_k=3)
    result = generate_guidance(chunks, {"riskLevel": "CRITICAL"}, shelter=None)
    print(json.dumps(result, ensure_ascii=False, indent=2))
