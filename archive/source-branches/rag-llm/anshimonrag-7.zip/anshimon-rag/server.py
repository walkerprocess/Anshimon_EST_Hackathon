# -*- coding: utf-8 -*-
"""Spring 연동용 FastAPI 서버

pipeline.generate_intervention_plan()을 HTTP로 노출한다. Spring 백엔드는
이 서버를 내부망에서 호출하는 방식으로 붙는다 (elderly/risk/shelter/weather
모듈이 각자 조회한 데이터를 그대로 body에 실어 보내면 된다).

실행:
    uvicorn server:app --host 0.0.0.0 --port 8000

요청 예시:
    POST /v1/intervention-plans
    {
      "elderlyId": 101,
      "riskSnapshotId": 812,
      "elderlyProfile": {"targetAudience": ["ELDERLY"], "age": 82, "livesAlone": true},
      "riskSnapshot": {"riskLevel": "HIGH", "riskScore": 0.83, "riskFactors": ["독거", "고령"]},
      "shelter": {"name": "...", "address": "...", "walkMinutes": 3, "needsReview": false},
      "weather": {"temperatureC": 36.2, "heatWarning": "폭염경보"}
    }

성공(200): 기획안 6.2 "최종 안내 계획" 스키마(camelCase) JSON을 그대로 반환.
근거 검증 ERROR(422): 자동전화를 보류해야 한다는 뜻. body에 어떤 검증이 왜
실패했는지(issues)가 들어있으니 Spring은 이 응답을 받으면 자동전화를 걸지 않고
issues를 로그/알림으로 노출해야 한다.
"""
from __future__ import annotations

from typing import Optional

from fastapi import FastAPI, HTTPException

from pipeline import GuidanceGenerationError, generate_intervention_plan
from schemas import ContractModel

app = FastAPI(
    title="안심온 LLM/RAG 서버",
    description="문서 수집·청킹, 검색, 프롬프트, 생성, 근거 검증을 묶은 안내 계획 생성 API",
    version="1.0.0",
)


class InterventionPlanRequest(ContractModel):
    elderly_id: int
    risk_snapshot_id: int
    elderly_profile: dict
    risk_snapshot: dict
    shelter: Optional[dict] = None
    weather: Optional[dict] = None


@app.get("/health")
def health() -> dict:
    return {"status": "ok"}


@app.post("/v1/intervention-plans")
def create_intervention_plan(payload: InterventionPlanRequest) -> dict:
    try:
        return generate_intervention_plan(
            elderly_id=payload.elderly_id,
            risk_snapshot_id=payload.risk_snapshot_id,
            elderly_profile=payload.elderly_profile,
            risk_snapshot=payload.risk_snapshot,
            shelter=payload.shelter,
            weather=payload.weather,
        )
    except GuidanceGenerationError as e:
        raise HTTPException(
            status_code=422,
            detail={
                "error": "GUIDANCE_GENERATION_BLOCKED",
                "message": str(e),
                "issues": [
                    {
                        "level": issue.level,
                        "code": issue.code,
                        "message": issue.message,
                        "sentence": issue.sentence,
                    }
                    for issue in e.issues
                ],
            },
        )
    except FileNotFoundError as e:
        # 예: ingest.py를 아직 안 돌려서 out/chunks.jsonl이 없는 경우
        raise HTTPException(status_code=503, detail={"error": "RAG_STORE_NOT_READY", "message": str(e)})
